package FoodLink;

import static org.junit.Assert.*;

import org.junit.Test;

import FoodLink.gui.SupermarketSys;

public class TestSupermarketSys {

	@Test
	public void testSuccessInit() {
		SupermarketSys s = new SupermarketSys(1, false);
		
		
	}

}
