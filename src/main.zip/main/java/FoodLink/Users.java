package FoodLink;

public class Users {
	/*
	public final static int USER_ADMIN = 4;
	public final static int USER_MANAGER = 3;
	public final static int USER_NORMAL = 2;
	*/
	public int accessLevel;
	private String userID;
	private String firstName;
	private String lastName;
	
	public Users(){
		
	}
	
	/*
	public Users(String id, String fn, String ln){
		userID = id;
		firstName = fn;
		lastName = ln;
	}*/
	
	public void addUser(){
		
	}
	
	public void removeUser(){
		
	}
	
	public void editUser(){
		
	}
}
