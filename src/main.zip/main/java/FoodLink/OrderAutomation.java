package FoodLink;

public class OrderAutomation {
	String orderRecs;
	
	//supplier or market
	private String getRecords(String client){
		return orderRecs;
	}
	
	
	//@param: threshold, product
	private void autoSetup(){	
		
	}
}
